
from jam.wsgi import create_application

application = create_application(__file__)
