__version__ = (7, 0, 77)

def version():
    return '%s.%s.%s' % __version__
