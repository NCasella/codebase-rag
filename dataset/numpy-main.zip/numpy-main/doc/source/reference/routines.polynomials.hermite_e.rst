.. automodule:: numpy.polynomial.hermite_e
   :no-members:
   :no-inherited-members:
   :no-special-members:
