.. _typing:
.. automodule:: numpy.typing
