.. automodule:: numpy.polynomial.laguerre
   :no-members:
   :no-inherited-members:
   :no-special-members:
