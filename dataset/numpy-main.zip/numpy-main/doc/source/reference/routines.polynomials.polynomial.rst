.. automodule:: numpy.polynomial.polynomial
   :no-members:
   :no-inherited-members:
   :no-special-members:
